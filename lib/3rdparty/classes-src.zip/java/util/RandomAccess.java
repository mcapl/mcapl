package java.util;

/**
 * Just some interface that something allowes efficient RandomAccess (for example a List).
 * @author Sven Köhler
 */
public interface RandomAccess
{
	//nothing, just an indicator interface
}
