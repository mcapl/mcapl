package java.lang;

public class InterruptedException extends Exception
{
	public InterruptedException()
	{
		super();
	}

	public InterruptedException(String message)
	{
		super(message);
	}	
}
