package java.lang;

public class IllegalStateException extends RuntimeException
{
	public IllegalStateException()
	{
		super();
	}

	public IllegalStateException(String message)
	{
		super(message);
	}	
}
