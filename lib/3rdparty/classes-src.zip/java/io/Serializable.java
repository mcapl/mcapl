package java.io;

/**
 * This interface is not functional. It's here
 * to satisfy jikes.
 */
public interface Serializable
{

}
