This ZIP-file contains the Java sources only. It does not contain any supplementary
files like project config files for Eclipse, Ant build scripts, etc.

To get ready-to-develop projects for Eclipse and Ant build scripts download
the source tarball from the leJOS download page.
