package javax.microedition.location;

/**
 * Used to load and save landmark information on the File system.
 * Currently unimplemented because it is unlikely this class would be used by NXT programmers.
 * If you require this class, please send an email to bbagnall@mts.net, or if you want to  
 * implement this yourself, please submit your final code to one of the leJOS developers.
 *
 */
class LandmarkStore {
	// TODO: Fill in some code.
}