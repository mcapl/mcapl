package java.lang;

public class NoSuchFieldError extends Error
{
	public NoSuchFieldError()
	{
		super();
	}

	public NoSuchFieldError(String message)
	{
		super(message);
	}
}
