package java.lang;

public class CloneNotSupportedException extends Exception
{
	public CloneNotSupportedException()
	{
		super();
	}

	public CloneNotSupportedException(String message)
	{
		super(message);
	}
}
