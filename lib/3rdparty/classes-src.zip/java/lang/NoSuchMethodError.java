package java.lang;

public class NoSuchMethodError extends Error
{
	public NoSuchMethodError()
	{
		super();
	}

	public NoSuchMethodError(String message)
	{
		super(message);
	}	
}
