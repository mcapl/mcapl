package java.lang;

public class ArithmeticException extends Exception
{
	public ArithmeticException()
	{
		super();
	}

	public ArithmeticException(String message)
	{
		super(message);
	}	
}
