package javax.microedition.lcdui;

/**
 * 
 * @author Andre Nijholt
 */
public interface CommandListener {
	public void commandAction(Command c, Displayable d);
}
